import py_canvas

dominio = "academy.redhouse.com.br"
access_token = "7RlfPf7Hljtyhtwb16oPj7w6OpD7L94cT8rbwoSwfQtCFMt19SLP48EAMlCUGhar"

retorno = py_canvas.users(dominio, access_token).list_users_in_account()

print(retorno)