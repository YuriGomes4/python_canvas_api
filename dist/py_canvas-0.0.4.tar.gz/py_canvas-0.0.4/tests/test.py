import py_canvas
import datetime

dominio = "academy.redhouse.com.br"
access_token = "zUAUzzPwjOLDHLuKXfCBLlQXcPrvlL4nGYOegFaG1947woPwRWHMTnDs3naAHaWW"
account_id = 1

data_limite = datetime.datetime(2024, 6, 30)

usuarios = py_canvas.users(dominio, access_token).list_users_in_account(account_id, sort="last_login", order="asc", page=100, per_page=10)

print(f"Quantidade de usuários que logaram após a data limite: {len(usuarios)}")


pagina = 2
qnt = 0

while len(usuarios) == 10:

    usuarios = py_canvas.users(dominio, access_token).list_users_in_account(account_id, sort="last_login", order="asc", page=pagina, per_page=10)

    for usuario in usuarios:
        qnt += 1

    print(f"Quantidade de usuários que logaram após a data limite: {qnt}")

    pagina += 1

print(f"Quantidade de usuários que logaram após a data limite: {qnt}")
print(f"Quantidade de páginas: {pagina-1}")